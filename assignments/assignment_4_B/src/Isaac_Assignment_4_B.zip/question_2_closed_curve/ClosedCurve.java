package question_2_closed_curve;

abstract public class ClosedCurve {
	abstract double computeArea();

}
